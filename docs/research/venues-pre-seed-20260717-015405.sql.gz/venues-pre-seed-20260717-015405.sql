--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg110+2)
-- Dumped by pg_dump version 16.4 (Debian 16.4-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: venues; Type: TABLE; Schema: public; Owner: lia_prod
--

CREATE TABLE public.venues (
    id uuid NOT NULL,
    name text NOT NULL,
    address text DEFAULT ''::text NOT NULL,
    metro text DEFAULT ''::text NOT NULL,
    district text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lat double precision,
    lon double precision,
    geog public.geography(Point,4326) GENERATED ALWAYS AS ((public.st_setsrid(public.st_makepoint(lon, lat), 4326))::public.geography) STORED
);


ALTER TABLE public.venues OWNER TO lia_prod;

--
-- Data for Name: venues; Type: TABLE DATA; Schema: public; Owner: lia_prod
--

COPY public.venues (id, name, address, metro, district, created_at, updated_at, lat, lon) FROM stdin;
a0000000-0000-0000-0000-000000000001	Музей «Гараж»	ул. Крымский Вал, 9, стр. 32	Парк культуры	ЦАО	2026-06-23 11:49:44.762705+00	2026-06-23 11:49:44.762705+00	55.72899	37.60151
a0000000-0000-0000-0000-000000000002	Дом культуры «ГЭС-2»	Болотная наб., 15	Кропоткинская	ЦАО	2026-06-23 11:49:44.762705+00	2026-06-23 11:49:44.762705+00	55.74028	37.60954
a0000000-0000-0000-0000-000000000003	Новая Третьяковка	ул. Крымский Вал, 10	Октябрьская	ЦАО	2026-06-23 11:49:44.762705+00	2026-06-23 11:49:44.762705+00	55.7344	37.6049
a0000000-0000-0000-0000-000000000004	ГМИИ им. Пушкина	ул. Волхонка, 12	Кропоткинская	ЦАО	2026-06-23 11:49:44.762705+00	2026-06-23 11:49:44.762705+00	55.7447	37.6059
a0000000-0000-0000-0000-000000000005	Центр «Зотов»	ул. Ходынская, 2, стр. 1	Улица 1905 года	ЦАО	2026-06-23 11:49:44.762705+00	2026-06-23 11:49:44.762705+00	55.7666	37.5604
a0000000-0000-0000-0000-000000000006	Центр «Винзавод»	4-й Сыромятнический пер., 1	Чкаловская	ЦАО	2026-06-23 11:49:44.762705+00	2026-06-23 11:49:44.762705+00	55.7547	37.6642
a0000000-0000-0000-0000-000000000007	Электротеатр «Станиславский»	ул. Тверская, 23	Тверская	ЦАО	2026-06-23 11:49:44.762705+00	2026-06-23 11:49:44.762705+00	55.7661	37.6019
a0000000-0000-0000-0000-000000000008	Еврейский музей	ул. Образцова, 11, стр. 1А	Марьина Роща	СВАО	2026-06-23 11:49:44.762705+00	2026-06-23 11:49:44.762705+00	55.7922	37.6048
e285ec6f-7fb0-4d38-b8ea-1d7418997bea	чапаевский 8				2026-06-26 10:28:39.781001+00	2026-06-26 10:28:47.126414+00	55.8005765	37.5192405
26d73ff2-b2c4-4cb8-9521-540bcfc22b34	Парк Горького				2026-07-14 22:11:50.16551+00	2026-07-14 22:11:50.16551+00	\N	\N
\.


--
-- Name: venues venue_id_pkey; Type: CONSTRAINT; Schema: public; Owner: lia_prod
--

ALTER TABLE ONLY public.venues
    ADD CONSTRAINT venue_id_pkey PRIMARY KEY (id);


--
-- Name: venue_name_lower_idx; Type: INDEX; Schema: public; Owner: lia_prod
--

CREATE INDEX venue_name_lower_idx ON public.venues USING btree (lower(name));


--
-- Name: venues_geog_gist; Type: INDEX; Schema: public; Owner: lia_prod
--

CREATE INDEX venues_geog_gist ON public.venues USING gist (geog);


--
-- Name: venues update_venue_updated_at; Type: TRIGGER; Schema: public; Owner: lia_prod
--

CREATE TRIGGER update_venue_updated_at BEFORE UPDATE ON public.venues FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- PostgreSQL database dump complete
--

